from django.contrib import admin
from django.urls import path
from django.views.generic import TemplateView
from mythology.views import pantheon_view, timeline_view, tree_view  # <-- Импорт

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', TemplateView.as_view(template_name='mythology/pages/index.html')),

    path('pantheon/', pantheon_view, name='pantheon'),
    path('timeline/', timeline_view, name='timeline'),
    path('tree/', tree_view, name='tree'),
]

