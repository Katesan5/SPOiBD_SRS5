from django.apps import AppConfig


class MythologyConfig(AppConfig):
    name = 'mythology'
