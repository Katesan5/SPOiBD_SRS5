from django.db import models
from django.core.validators import MinValueValidator, MaxValueValidator
class Realm(models.Model):
    name = models.CharField("Название мира", max_length=100, unique=True)
    description = models.TextField("Описание", blank=True)

    class Meta:
        verbose_name = "Мир"
        verbose_name_plural = "Миры"
        ordering = ['name']

    def __str__(self):
        return self.name

class Deity(models.Model):
    CLAN_CHOICES = [
        ('AESIR', 'Асы'),
        ('VANIR', 'Ваны'),
        ('JOTUN', 'Ётуны'),
        ('OTHER', 'Прочие'),
    ]

    name = models.CharField("Имя", max_length=150)
    epithet = models.CharField("Эпитет/Титул", max_length=200, blank=True, help_text="Например: Громовержец, Хромой")
    clan = models.CharField("Клан", max_length=10, choices=CLAN_CHOICES, default='AESIR')
    power_level = models.IntegerField("Уровень силы", validators=[MinValueValidator(1), MaxValueValidator(10)],
                                      default=5)
    biography = models.TextField("Биография", blank=True)

    realms = models.ManyToManyField(Realm, related_name='deities', blank=True, verbose_name="Миры обитания")

    image_url = models.URLField("Ссылка на изображение", blank=True, help_text="URL картинки для интерфейса")

    class Meta:
        verbose_name = "Божество"
        verbose_name_plural = "Божества"
        ordering = ['name']

    def __str__(self):
        return f"{self.name} ({self.get_clan_display()})"


class Relation(models.Model):
    RELATION_TYPES = [
        ('PARENT', 'Родитель'),
        ('CHILD', 'Ребенок'),
        ('SPOUSE', 'Супруг(а)'),
        ('SIBLING', 'Брат/Сестра'),
        ('ENEMY', 'Враг'),
        ('ALLY', 'Союзник'),
    ]

    from_deity = models.ForeignKey(Deity, on_delete=models.CASCADE, related_name='relations_from',
                                   verbose_name="От кого")
    to_deity = models.ForeignKey(Deity, on_delete=models.CASCADE, related_name='relations_to', verbose_name="К кому")
    relation_type = models.CharField("Тип связи", max_length=10, choices=RELATION_TYPES)
    strength = models.IntegerField("Сила связи", default=5, help_text="Для визуализации толщины линии на графе (1-10)")

    class Meta:
        verbose_name = "Связь"
        verbose_name_plural = "Связи"
        unique_together = ('from_deity', 'to_deity', 'relation_type')

    def __str__(self):
        return f"{self.from_deity} -> {self.to_deity} ({self.get_relation_type_display()})"


class Event(models.Model):
    title = models.CharField("Название события", max_length=200)
    date_desc = models.CharField("Датировка (мифологическая)", max_length=100,
                                 help_text="Например: 'До сотворения мира', 'Начало Рагнарёка'")
    description = models.TextField("Описание")

    participants = models.ManyToManyField(Deity, related_name='events', blank=True, verbose_name="Участники")

    sort_order = models.IntegerField("Порядок", default=0)

    class Meta:
        verbose_name = "Событие"
        verbose_name_plural = "События (Хронология)"
        ordering = ['sort_order']

    def __str__(self):
        return self.title