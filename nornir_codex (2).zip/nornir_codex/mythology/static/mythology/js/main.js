document.addEventListener('DOMContentLoaded', function() {

    // --- 1. УПРАВЛЕНИЕ ТЕМОЙ (СОСТОЯНИЕ 1) ---
    const themeToggle = document.createElement('button');
    themeToggle.id = 'theme-toggle';
    themeToggle.innerHTML = '️';
    themeToggle.style.cssText = 'position:fixed; bottom:20px; right:20px; z-index:1000; background:var(--nc-gold); border:none; border-radius:50%; width:50px; height:50px; cursor:pointer; font-size:1.5rem; box-shadow:0 4px 15px rgba(0,0,0,0.1); transition:all 0.3s; display:flex; align-items:center; justify-content:center;';
    document.body.appendChild(themeToggle);

    function applyTheme(isLight) {
        if (isLight) {
            document.documentElement.setAttribute('data-bs-theme', 'light');
            document.documentElement.style.setProperty('--nc-bg-main', '#f1f5f9');
            document.documentElement.style.setProperty('--nc-bg-sidebar', '#e2e8f0');
            document.documentElement.style.setProperty('--nc-bg-card', '#ffffff');
            document.documentElement.style.setProperty('--tblr-body-color', '#1e293b');
            document.documentElement.style.setProperty('--nc-gold', '#8a734b');
            document.documentElement.style.setProperty('--nc-neon', '#0f766e');
            themeToggle.innerHTML = '🌙';
            themeToggle.style.background = '#cbd5e1';
            themeToggle.style.color = '#1e293b';
        } else {
            document.documentElement.setAttribute('data-bs-theme', 'dark');
            document.documentElement.style.setProperty('--nc-bg-main', '#050810');
            document.documentElement.style.setProperty('--nc-bg-sidebar', '#0f172a');
            document.documentElement.style.setProperty('--nc-bg-card', '#111827');
            document.documentElement.style.setProperty('--tblr-body-color', '#cbd5e1');
            document.documentElement.style.setProperty('--nc-gold', '#F9E79F');
            document.documentElement.style.setProperty('--nc-neon', '#38bdf8');
            themeToggle.innerHTML = '☀️';
            themeToggle.style.background = 'var(--nc-gold)';
            themeToggle.style.color = '#050810';
        }
        localStorage.setItem('nornir_theme', isLight ? 'light' : 'dark');
    }

    const savedTheme = localStorage.getItem('nornir_theme');
    applyTheme(savedTheme === 'light');

    themeToggle.addEventListener('click', () => {
        const current = localStorage.getItem('nornir_theme') === 'light';
        applyTheme(!current);
    });

    // --- 2. ФИЛЬТРАЦИЯ ПАНТЕОНА ЧЕРЕЗ FETCH (ДИНАМИЧНОСТЬ + СОСТОЯНИЕ 2) ---
    const filterContainer = document.getElementById('clan-filters');
    const godsGrid = document.getElementById('gods-grid');

    if (filterContainer && godsGrid) {
        const savedClan = localStorage.getItem('nornir_clan_filter');
        if (savedClan) {
            fetchGods(savedClan);
            updateActiveButton(savedClan);
        }

        filterContainer.addEventListener('click', (e) => {
            if (e.target.classList.contains('filter-chip')) {
                const clan = e.target.dataset.clan;
                fetchGods(clan);
                updateActiveButton(clan);
                localStorage.setItem('nornir_clan_filter', clan);
            }
        });

        function updateActiveButton(clan) {
            document.querySelectorAll('.filter-chip').forEach(btn => {
                btn.classList.toggle('active', btn.dataset.clan === clan);
            });
        }

        function fetchGods(clan) {
            const url = clan ? `/pantheon/?clan=${clan}` : '/pantheon/';

            fetch(url, {
                headers: { 'X-Requested-With': 'XMLHttpRequest' }
            })
            .then(response => response.json())
            .then(data => {
                renderGods(data.deities);
            })
            .catch(err => console.error('Ошибка загрузки:', err));
        }

        function renderGods(gods) {
            godsGrid.innerHTML = '';
            if (gods.length === 0) {
                godsGrid.innerHTML = '<p style="color:#64748b; grid-column:1/-1; text-align:center;">В этой категории пока нет богов.</p>';
                attachGodModalEvents();
                return;
            }

            gods.forEach(god => {
                const card = document.createElement('div');
                card.className = 'god-card';
                card.dataset.name = god.name;
                card.dataset.bio = god.biography;
                card.dataset.clan = god.clan;

                card.innerHTML = `
                    <div class="god-avatar"><span>${god.initial}</span></div>
                    <div class="god-info">
                        <h3>${god.name}</h3>
                        <p class="god-epithet">${god.epithet}</p>
                        <span class="clan-badge ${god.clan}">${god.clan_display}</span>
                    </div>
                `;
                godsGrid.appendChild(card);
            });

            attachGodModalEvents();
        }
    }

    // --- 3. УНИВЕРСАЛЬНОЕ МОДАЛЬНОЕ ОКНО (БОГИ + СОБЫТИЯ) ---
    const modal = document.getElementById('god-modal');

    function openModal(name, bio, initial, clanDisplay, clanClass, isEvent = false) {
        if (!modal) return;

        const avatarEl = document.getElementById('modal-avatar');
        const nameEl = document.getElementById('modal-name');
        const clanEl = document.getElementById('modal-clan');
        const bioEl = document.getElementById('modal-bio');

        if (isEvent) {
            avatarEl.textContent = 'ᛟ';
            avatarEl.style.borderColor = 'var(--nc-neon)';
            avatarEl.style.color = 'var(--nc-neon)';
            nameEl.textContent = name;
            clanEl.textContent = clanDisplay;
            clanEl.className = 'clan-badge';
            clanEl.style.background = 'rgba(56, 189, 248, 0.1)';
            clanEl.style.color = 'var(--nc-neon)';
            bioEl.textContent = bio;
        } else {
            avatarEl.textContent = initial || '?';
            avatarEl.style.borderColor = 'var(--nc-gold)';
            avatarEl.style.color = 'var(--nc-gold)';
            nameEl.textContent = name;
            clanEl.textContent = clanDisplay;
            clanEl.className = `clan-badge ${clanClass}`;
            clanEl.style.background = '';
            clanEl.style.color = '';
            bioEl.textContent = bio || 'Древние записи об этом боге утеряны во времени...';
        }

        modal.classList.remove('hidden');
    }

    function attachGodModalEvents() {
        const godCards = document.querySelectorAll('.god-card, .tree-card');

        godCards.forEach(card => {
            if (card.dataset.name) {
                card.style.cursor = 'pointer';
                // Удаляем старые обработчики, чтобы не дублировались при AJAX
                const newCard = card.cloneNode(true);
                card.parentNode.replaceChild(newCard, card);

                newCard.addEventListener('click', () => {
                    const avatarText = newCard.querySelector('.god-avatar span, .card-avatar')?.textContent.trim() || '?';
                    const badgeText = newCard.querySelector('.clan-badge')?.textContent || '';

                    openModal(
                        newCard.dataset.name,
                        newCard.dataset.bio,
                        avatarText,
                        badgeText,
                        newCard.dataset.clan || ''
                    );
                });
            }
        });
    }

    function attachEventModalEvents() {
        const eventCards = document.querySelectorAll('.event-card');

        eventCards.forEach(card => {
            const title = card.querySelector('h3')?.textContent;
            const date = card.querySelector('.event-date')?.textContent;
            const desc = card.querySelector('p')?.textContent;

            if (title) {
                card.style.cursor = 'pointer';
                card.addEventListener('click', () => {
                    openModal(title, desc, '', date, '', true);
                });
            }
        });
    }

    // Инициализация обработчиков кликов
    attachGodModalEvents();
    attachEventModalEvents();

    // Закрытие модалки
    if (modal) {
        modal.querySelector('.modal-close').addEventListener('click', () => {
            modal.classList.add('hidden');
        });

        modal.addEventListener('click', (e) => {
            if (e.target === modal) modal.classList.add('hidden');
        });

        // Закрытие по Escape
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') modal.classList.add('hidden');
        });
    }
});