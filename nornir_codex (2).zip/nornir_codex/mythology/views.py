# mythology/views.py

from django.shortcuts import render
from django.http import JsonResponse
from .models import Deity, Event


def pantheon_view(request):
    deities = Deity.objects.all()

    clan_filter = request.GET.get('clan')
    if clan_filter:
        deities = deities.filter(clan=clan_filter.upper())

    is_ajax = request.headers.get('X-Requested-With') == 'XMLHttpRequest'

    if is_ajax:
        data = []
        for god in deities:
            data.append({
                'name': god.name,
                'epithet': god.epithet,
                'clan': god.clan,
                'clan_display': god.get_clan_display(),
                'biography': god.biography or '',
                'initial': god.name[:1]
            })
        return JsonResponse({'deities': data})

    context = {
        'deities': deities,
        'current_clan': clan_filter
    }
    return render(request, 'mythology/pages/pantheon.html', context)


def timeline_view(request):
    events = Event.objects.all().order_by('sort_order')
    context = {'events': events}
    return render(request, 'mythology/pages/timeline.html', context)


def tree_view(request):
    deities = Deity.objects.all().order_by('name')
    context = {'deities': deities}
    return render(request, 'mythology/pages/tree.html', context)