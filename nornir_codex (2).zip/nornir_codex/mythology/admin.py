from django.contrib import admin
from .models import Realm, Deity, Relation, Event

@admin.register(Realm)
class RealmAdmin(admin.ModelAdmin):
    list_display = ('name',)

@admin.register(Deity)
class DeityAdmin(admin.ModelAdmin):
    list_display = ('name', 'clan', 'power_level')
    list_filter = ('clan', 'realms')
    search_fields = ('name', 'epithet')

@admin.register(Relation)
class RelationAdmin(admin.ModelAdmin):
    list_display = ('from_deity', 'relation_type', 'to_deity')
    list_filter = ('relation_type',)

@admin.register(Event)
class EventAdmin(admin.ModelAdmin):
    list_display = ('title', 'date_desc', 'sort_order')
    list_editable = ('sort_order',)