from django.core.management.base import BaseCommand
from mythology.models import Deity, Realm, Relation, Event
class Command(BaseCommand):
    help = 'Заполняет БД полной родословной скандинавских богов'

    def handle(self, *args, **options):
        self.stdout.write('Загрузка родословной...')

        realms = {
            'asgard': Realm.objects.get_or_create(name='Асгард', defaults={'description': 'Мир Эсов'})[0],
            'vanaheim': Realm.objects.get_or_create(name='Ванахейм', defaults={'description': 'Мир Ванов'})[0],
            'jotunheim': Realm.objects.get_or_create(name='Ётунхейм', defaults={'description': 'Мир Великанов'})[0],
            'midgard': Realm.objects.get_or_create(name='Мидгард', defaults={'description': 'Мир Людей'})[0],
        }
        def create_deity(name, epithet='', clan='AESIR', bio='', realm_key=None):
            d, _ = Deity.objects.get_or_create(
                name=name,
                defaults={
                    'epithet': epithet,
                    'clan': clan,
                    'biography': bio,
                    'power_level': 5
                }
            )
            if realm_key and realm_key in realms:
                d.realms.add(realms[realm_key])
            return d

        ymir = create_deity('Имир', 'Первозданный великан', 'JOTUN', 'Из него возникли земля и небо.', 'jotunheim')
        buri = create_deity('Бури', 'Первый бог', 'AESIR', 'Рожден изо льда коровой Аудумлой.', 'asgard')

        bor = create_deity('Бор', 'Сын Бури', 'AESIR', 'Отец Одина, Вили и Ве.', 'asgard')
        bestla = create_deity('Бестла', 'Великанша', 'JOTUN', 'Мать Одина, дочь великана Болторна.', 'jotunheim')

        Relation.objects.get_or_create(from_deity=bor, to_deity=bestla, relation_type='SPOUSE')

        odin = create_deity('Один', 'Всеотец', 'AESIR', 'Верховный бог, властитель Асгарда.', 'asgard')
        vili = create_deity('Вили', 'Бог воли', 'AESIR', 'Брат Одина.', 'asgard')
        ve = create_deity('Ве', 'Бог святыни', 'AESIR', 'Брат Одина.', 'asgard')

        for son in [odin, vili, ve]:
            Relation.objects.get_or_create(from_deity=bor, to_deity=son, relation_type='PARENT')
            Relation.objects.get_or_create(from_deity=bestla, to_deity=son, relation_type='PARENT')

        frigg = create_deity('Фригг', 'Верховная богиня', 'AESIR', 'Жена Одина, богиня брака и материнства.', 'asgard')
        Relation.objects.get_or_create(from_deity=odin, to_deity=frigg, relation_type='SPOUSE')

        thor = create_deity('Тор', 'Громовержец', 'AESIR', 'Защитник Асгарда и Мидгарда.', 'asgard')
        baldr = create_deity('Бальдр', 'Бог света', 'AESIR', 'Самый прекрасный и любимый из богов.', 'asgard')
        hodr = create_deity('Хёд', 'Слепой бог', 'AESIR', 'Брат Бальдра, невольно убивший его.', 'asgard')
        hermod = create_deity('Хермод', 'Вестник богов', 'AESIR', 'Посланник Одина.', 'asgard')
        tyr = create_deity('Тюр', 'Бог войны', 'AESIR', 'Бог справедливости и победы.', 'asgard')
        vidar = create_deity('Видар', 'Молчаливый бог', 'AESIR', 'Бог мести, сын великанши Грид.', 'asgard')
        vali = create_deity('Вали', 'Бог возмездия', 'AESIR', 'Рожден за одну ночь, чтобы отомстить за Бальдра.',
                            'asgard')
        bragi = create_deity('Браги', 'Бог поэзии', 'AESIR', 'Муж Идунн, хранитель скальдов.', 'asgard')
        heimdall = create_deity('Хеймдалль', 'Страж Биврёста', 'AESIR', 'Сын девяти матерей-великанш.', 'asgard')

        for child in [thor, baldr, hodr, hermod, tyr, vidar, vali, bragi, heimdall]:
            Relation.objects.get_or_create(from_deity=odin, to_deity=child, relation_type='PARENT')
            Relation.objects.get_or_create(from_deity=frigg, to_deity=child, relation_type='PARENT')

        sif = create_deity('Сиф', 'Златокудрая', 'AESIR', 'Жена Тора.', 'asgard')
        Relation.objects.get_or_create(from_deity=thor, to_deity=sif, relation_type='SPOUSE')

        magni = create_deity('Магни', 'Сильнейший', 'AESIR', 'Сын Тора.', 'asgard')
        modi = create_deity('Моди', 'Яростный', 'AESIR', 'Сын Тора.', 'asgard')
        thrud = create_deity('Труд', 'Сила', 'AESIR', 'Дочь Тора.', 'asgard')

        for child in [magni, modi, thrud]:
            Relation.objects.get_or_create(from_deity=thor, to_deity=child, relation_type='PARENT')
            Relation.objects.get_or_create(from_deity=sif, to_deity=child, relation_type='PARENT')

        nanna = create_deity('Нанна', 'Верная жена', 'AESIR', 'Жена Бальдра.', 'asgard')
        Relation.objects.get_or_create(from_deity=baldr, to_deity=nanna, relation_type='SPOUSE')
        forseti = create_deity('Форсети', 'Бог правосудия', 'AESIR', 'Сын Бальдра и Нанны.', 'asgard')
        Relation.objects.get_or_create(from_deity=baldr, to_deity=forseti, relation_type='PARENT')
        Relation.objects.get_or_create(from_deity=nanna, to_deity=forseti, relation_type='PARENT')

        idunn = create_deity('Идунн', 'Хранительница яблок', 'AESIR', 'Богиня вечной молодости.', 'asgard')
        Relation.objects.get_or_create(from_deity=bragi, to_deity=idunn, relation_type='SPOUSE')

        njord = create_deity('Ньёрд', 'Бог моря', 'VANIR', 'Отец Фрейра и Фрейи.', 'vanaheim')
        skadi = create_deity('Скади', 'Богиня охоты', 'JOTUN', 'Великанша, бывшая жена Ньёрда.', 'jotunheim')
        Relation.objects.get_or_create(from_deity=njord, to_deity=skadi, relation_type='SPOUSE')

        freyr = create_deity('Фрейр', 'Бог плодородия', 'VANIR', 'Владелец Альвхейма.', 'vanaheim')
        freya = create_deity('Фрейя', 'Богиня любви', 'VANIR', 'Предводительница валькирий.', 'vanaheim')

        Relation.objects.get_or_create(from_deity=njord, to_deity=freyr, relation_type='PARENT')
        Relation.objects.get_or_create(from_deity=njord, to_deity=freya, relation_type='PARENT')
        Relation.objects.get_or_create(from_deity=skadi, to_deity=freyr, relation_type='PARENT')
        Relation.objects.get_or_create(from_deity=skadi, to_deity=freya, relation_type='PARENT')

        gerd = create_deity('Герд', 'Прекрасная великанша', 'JOTUN', 'Жена Фрейра.', 'jotunheim')
        Relation.objects.get_or_create(from_deity=freyr, to_deity=gerd, relation_type='SPOUSE')
        fjolnir = create_deity('Фьёльнир', 'Конунг', 'VANIR', 'Сын Фрейра и Герд.', 'vanaheim')
        Relation.objects.get_or_create(from_deity=freyr, to_deity=fjolnir, relation_type='PARENT')

        od = create_deity('Од', 'Таинственный супруг', 'AESIR', 'Муж Фрейи, часто отсутствующий.', 'asgard')
        Relation.objects.get_or_create(from_deity=freya, to_deity=od, relation_type='SPOUSE')
        hnosn = create_deity('Хносн', 'Сокровище', 'VANIR', 'Дочь Фрейи.', 'vanaheim')
        gersemi = create_deity('Герсеми', 'Драгоценность', 'VANIR', 'Дочь Фрейи.', 'vanaheim')
        Relation.objects.get_or_create(from_deity=freya, to_deity=hnosn, relation_type='PARENT')
        Relation.objects.get_or_create(from_deity=freya, to_deity=gersemi, relation_type='PARENT')

        loky = create_deity('Локи', 'Бог обмана', 'JOTUN', 'Названый брат Одина, трикстер.', 'asgard')
        sigyn = create_deity('Сигюн', 'Верная жена', 'JOTUN', 'Жена Локи.', 'jotunheim')
        angrboda = create_deity('Ангрбода', 'Великанша скорби', 'JOTUN', 'Мать чудовищ.', 'jotunheim')

        Relation.objects.get_or_create(from_deity=loky, to_deity=sigyn, relation_type='SPOUSE')
        Relation.objects.get_or_create(from_deity=loky, to_deity=angrboda, relation_type='SPOUSE')

        narvi = create_deity('Нарви', 'Сын Локи', 'JOTUN', '', 'jotunheim')
        vali_loki = create_deity('Вали (сын Локи)', 'Обращенный в волка', 'JOTUN', '', 'jotunheim')
        fenrir = create_deity('Фенрир', 'Великий волк', 'JOTUN', 'Сын Локи, destined to kill Odin.', 'jotunheim')
        jormungandr = create_deity('Ёрмунганд', 'Мировой змей', 'JOTUN', 'Опоясывает Мидгард.', 'jotunheim')
        hel = create_deity('Хель', 'Богиня смерти', 'JOTUN', 'Правительница Хельхейма.', 'helheim')
        sleipnir = create_deity('Слейпнир', 'Восьминогий конь', 'JOTUN', 'Лучший конь Одина, сын Локи.', 'asgard')

        Relation.objects.get_or_create(from_deity=loky, to_deity=narvi, relation_type='PARENT')
        Relation.objects.get_or_create(from_deity=sigyn, to_deity=narvi, relation_type='PARENT')

        Relation.objects.get_or_create(from_deity=loky, to_deity=vali_loki, relation_type='PARENT')
        Relation.objects.get_or_create(from_deity=sigyn, to_deity=vali_loki, relation_type='PARENT')

        Relation.objects.get_or_create(from_deity=loky, to_deity=fenrir, relation_type='PARENT')
        Relation.objects.get_or_create(from_deity=angrboda, to_deity=fenrir, relation_type='PARENT')

        Relation.objects.get_or_create(from_deity=loky, to_deity=jormungandr, relation_type='PARENT')
        Relation.objects.get_or_create(from_deity=angrboda, to_deity=jormungandr, relation_type='PARENT')

        Relation.objects.get_or_create(from_deity=loky, to_deity=hel, relation_type='PARENT')
        Relation.objects.get_or_create(from_deity=angrboda, to_deity=hel, relation_type='PARENT')

        Relation.objects.get_or_create(from_deity=loky, to_deity=sleipnir, relation_type='PARENT')

        Relation.objects.get_or_create(from_deity=loky, to_deity=thor, relation_type='ENEMY')

        self.stdout.write(self.style.SUCCESS('Родословная успешно загружена!'))